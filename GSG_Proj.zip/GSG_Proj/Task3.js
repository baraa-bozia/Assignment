
let arr = ['one', 'two', 'two', 'three', 'five', 'one', 'six'];
let arr2 = [];
arr.forEach(element => {
    if (!arr2.includes(element)) {
        arr2.push(element);
    }
});

console.log(arr2);
  


