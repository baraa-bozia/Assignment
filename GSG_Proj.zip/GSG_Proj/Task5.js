function isValidEmail(email) {
    var emaill = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emaill.test(email);
}
console.log(isValidEmail("example@domain.com"));
console.log(isValidEmail("exmaple"));
console.log(isValidEmail("example@sub.domain.com"));
