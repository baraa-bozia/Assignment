interface Product {
    name: string;
    price: number;
  }
  
  function calcTotalPrice(products: Product[]): number {
    return products.reduce((total, product) => total + product.price, 0);
  }
  
  const products: Product[] = [
    {name:'product 1', price:10},
    {name:'product 2', price:20},
    {name:'product 3', price:30},
  ];
  
  const totalPrice = calcTotalPrice(products);
  console.log(totalPrice);
  
//   explanation of how the TypeScript code works and any necessary instructions on how to run it, such as compiling TypeScript to JavaScript.
// first i run this command<< npm install -g typescript >> to install type script
// then tsc Task4.ts , a new js file appeared and then run this command Task4.js