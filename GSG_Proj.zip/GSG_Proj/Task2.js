const avgerage=(arr)=>{
    console.log(arr.reduce((a,b)=>a+b))
    return( arr.reduce((a,b) => a+b) / arr.length)

 // let avg = arr.reduce((a,b) => a+b) / arr.length
}

let arr=[1,2,3,4,5,6]

console.log(avgerage(arr));
