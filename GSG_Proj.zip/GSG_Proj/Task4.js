function calcTotalPrice(products) {
    return products.reduce(function (total, product) { return total + product.price; }, 0);
}
var products = [
    { name: 'product 1', price: 10 },
    { name: 'product 2', price: 20 },
    { name: 'product 3', price: 30 },
];
var totalPrice = calcTotalPrice(products);
console.log(totalPrice);
